package core.connections;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import core.Exceptions.CouponSystemException;

public class ConnectionPool {
	private Set<Connection> connections = new HashSet<>();

	private static ConnectionPool instance = new ConnectionPool();
	public static final int MAX_CON_SIZE = 10;
	private String url = "jdbc:mysql://localhost:3306/CSDB";
	private boolean shutDown = false;

	private ConnectionPool() {
		for (int i = 0; i < MAX_CON_SIZE; i++) {
			try {
	Class.forName("com.mysql.jdbc.Driver");		
				Connection con = DriverManager.getConnection(url, "root", "1234");
				connections.add(con);
			} catch (SQLException | ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * 
	 * @return a ConnectionPool class instance
	 */
	public static ConnectionPool getInstance() {
		return instance;
	}

	/**
	 * whenever there is available connection, it takes it out of the connection
	 * pool and returns it
	 * 
	 * @return A Connection type object
	 * @throws CouponSystemException
	 * @throws InterruptedException
	 *             if during its wait(); method for an available connection to
	 *             appear, it gets interrupted
	 */
	public synchronized Connection getConnection() throws CouponSystemException {
		if (shutDown == false) {

			while (connections.isEmpty()) {
				try {
					wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

			Iterator<Connection> it = connections.iterator();
			Connection con = it.next();
			it.remove();
			return con;
		} else {
			throw new CouponSystemException("the system is shutting down. cannot establish connection.");

		}
	}

	/**
	 * receives a connection and put it back in the connection pool
	 * 
	 * @param con
	 *            A connection type object
	 */
	public synchronized void returnConnection(Connection con) {
		connections.add(con);
		notify();

	}

	/**
	 * closes all of the exist connection in the connection pool
	 * 
	 * @throws CouponSystemException
	 * 
	 * @throws SqlException
	 *             if it fails to close the connections
	 */
	public synchronized void closeAllConnections() throws CouponSystemException {
		shutDown = true;
		System.out.println("closing all the connections...");
		try {
			wait(5000);

			for (Connection connection : connections) {
				if (!connection.isClosed()) {
					connection.close();

				}
			}
			connections.removeAll(connections);
			System.out.println("all connections are closed.");
		} catch (SQLException | InterruptedException e) {

			throw new CouponSystemException("error with closing the connections", e);
		}
	}
}
