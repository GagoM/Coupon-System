package core.couponSystemSingleton;

public enum ClientType {
	Customer, Company, Admin
}
