package core.couponSystemSingleton;

import java.sql.SQLException;

import core.Exceptions.CouponSystemException;
import core.Exceptions.LoginException;
import core.connections.ConnectionPool;
import core.facades.AdminFacade;
import core.facades.CompanyFacade;
import core.facades.CouponClientFacade;
import core.facades.CustomerFacade;
import core.tasks.DailyCouponExpirationTask;

public class CouponSystem {

	private AdminFacade adminFacade = new AdminFacade();
	private CustomerFacade customerFacade = new CustomerFacade();
	private CompanyFacade companyFacade = new CompanyFacade();

	private static CouponSystem instance = new CouponSystem();

	private DailyCouponExpirationTask task = new DailyCouponExpirationTask();
	private Thread dailyThread = null;

	/**
	 * the CTOR invokes the start method of the Daily task thread
	 */
	private CouponSystem() {

		dailyThread = new Thread(task);
		dailyThread.start();
	}

	/**
	 * 
	 * @return A CouponSystem instance
	 */
	public synchronized static CouponSystem getInstance() {
		if (instance == null) {
			instance = new CouponSystem();
			return instance;
		} else {
			return instance;
		}
	}

	/**
	 * calls the login method of a given client type
	 * 
	 * @param name
	 *            A client name
	 * @param password
	 *            A client password
	 * @param clientType
	 *            A clientType type object
	 * @return CouponClientFacade(admin facade, company facade or customer
	 *         facade)
	 * @throws LoginException
	 *             if the user name and password aren't match the database
	 * @throws CouponSystemException
	 *             if it fails to log in for any other reason
	 * @throws SQLException
	 * 
	 */
	public CouponClientFacade login(String name, String password, ClientType clientType)
			throws SQLException, CouponSystemException {
		if (clientType == ClientType.Admin) {
			return adminFacade.login(name, password, clientType);

		} else if (clientType == ClientType.Company) {
			return companyFacade.login(name, password, clientType);
		} else if (clientType == ClientType.Customer) {
			return customerFacade.login(name, password, clientType);
		} else {
			return null;
		}
	}

	/**
	 * stops the DailyCouponExpirationTask
	 * 
	 * @throws CouponSystemException
	 */
	public void shutdown() throws CouponSystemException {
		task.stopTask();
		dailyThread.interrupt();
		ConnectionPool.getInstance().closeAllConnections();

	}
	public CouponClientFacade login(String user, String pwd, String customerType)
	{
		switch (customerType)
		{
			case "admin" : if (user.equals("admin") && pwd.equals("1234"))
				return new AdminFacade();
				break;
			case "company" : if (user.equals("company") && pwd.equals("company"))
				return new CompanyFacade();
				break;
			case "customer" : if (user.equals("customer") && pwd.equals("customer"))
				return new CustomerFacade();
				break;
		}
		return null;
	}
}
