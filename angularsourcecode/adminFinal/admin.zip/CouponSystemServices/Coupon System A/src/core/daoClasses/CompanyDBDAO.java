package core.daoClasses;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import core.Exceptions.CouponSystemException;
import core.Exceptions.LoginException;
import core.Exceptions.UniqueNameException;
import core.connections.ConnectionPool;
import core.daoInterfaces.CompanyDao;
import core.javaBeans.Company;
import core.javaBeans.Coupon;
import core.javaBeans.CouponType;

public class CompanyDBDAO implements CompanyDao {

	public CompanyDBDAO() {
	}

	/**
	 * creates a new company in the database.
	 * 
	 * @param c
	 *            a Company type Object.
	 * @throws CouponSystemException
	 *             if it fails to create the company object in the database.
	 * @throws UniqueNameException
	 *             if the name of this company is already exists in the data
	 *             base
	 */

	@Override
	public void createCompany(Company c) throws CouponSystemException {

		Connection con = ConnectionPool.getInstance().getConnection();
		String sql = "INSERT INTO company ( COMP_NAME, PASSWORD, EMAIL) values(?,?,?)";

		if (checkUniqueName(c.getCompName()) == true) {
			try (PreparedStatement pstmt = con.prepareStatement(sql);) {

				pstmt.setString(1, c.getCompName());
				pstmt.setString(2, c.getPassword());
				pstmt.setString(3, c.getEmail());
				pstmt.executeUpdate();
				System.out.println("company: " + c.getCompName() + " created");

				c.setId(getIdForName(c.getCompName()));
			} catch (Exception e) {

				throw new CouponSystemException("failed to create the company", e);

			} finally {

				ConnectionPool.getInstance().returnConnection(con);
			}
		} else {
			throw new UniqueNameException("the company name is alaready exist in the database");
		}

	}

	/**
	 * deletes a given company from the database. deletes all of the company's
	 * coupons from the customer_coupon and company_coupon join tables.
	 * 
	 * @param c
	 *            a Company type Object.
	 * @throws CouponSystemException
	 *             if it fails to remove the company from the database
	 */

	@Override
	public void removeCompany(Company c) throws CouponSystemException {
		c.setId(getIdForName(c.getCompName()));

		String sql1 = "SELECT COUPON_ID FROM Company_Coupon WHERE COMP_ID = ?";
		String sql2 = "DELETE FROM Coupon WHERE ID= ?";
		String sql3 = "DELETE FROM Customer_Coupon WHERE COUPON_ID= ?";
		String sql4 = "DELETE FROM Company_Coupon WHERE COMP_ID=?";
		String sql5 = "DELETE FROM Company WHERE ID=?";

		Connection con = ConnectionPool.getInstance().getConnection();
		try (PreparedStatement pstmt1 = con.prepareStatement(sql1);
				PreparedStatement pstmt2 = con.prepareStatement(sql2);
				PreparedStatement pstmt3 = con.prepareStatement(sql3);
				PreparedStatement pstmt4 = con.prepareStatement(sql4);
				PreparedStatement pstmt5 = con.prepareStatement(sql5);) {

			pstmt1.setLong(1, c.getId());
			ResultSet rs = pstmt1.executeQuery();
			Set<Long> couponIds = new HashSet<>();
			while (rs.next()) {
				couponIds.add(rs.getLong(1));
			}
			for (long couponId : couponIds) {
				pstmt2.setLong(1, couponId);
				pstmt2.executeUpdate();
				pstmt3.setLong(1, couponId);
				pstmt3.executeUpdate();

			}
			pstmt4.setLong(1, c.getId());
			pstmt4.executeUpdate();
			pstmt5.setLong(1, c.getId());
			pstmt5.executeUpdate();
			System.out.println("company: " + c.getCompName() + " removed");
		} catch (SQLException e) {
			throw new CouponSystemException("removing company failed", e);
		} finally {
			ConnectionPool.getInstance().returnConnection(con);
		}

	}

	/**
	 * updates the details of a specific company in the database. the method
	 * doesn't updates the company name.
	 * 
	 * @param c
	 *            a company type object
	 * @throws CouponSystemException
	 *             if it fails to update the company details in the database.
	 * 
	 */

	@Override
	public void updateCompany(Company c) throws CouponSystemException {
		c.setId(getIdForName(c.getCompName()));
		Connection con = ConnectionPool.getInstance().getConnection();
		String sql = "UPDATE Company set password=? ,email=? WHERE id=?";
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {

			pstmt.setString(1, c.getPassword());
			pstmt.setString(2, c.getEmail());
			pstmt.setLong(3, getIdForName(c.getCompName()));
			pstmt.executeUpdate();
			System.out.println("company: " + c.getCompName() + " updated");

		} catch (SQLException e) {
			throw new CouponSystemException("updating Company failed", e);
		} finally {
			ConnectionPool.getInstance().returnConnection(con);
		}

	}

	/**
	 * reads a company details from the database given the company's ID.
	 * 
	 * @param id
	 *            A company ID
	 * @return A company type object
	 * @throws CouponSystemException
	 *             if it fails to read the company from the database.
	 * 
	 */
	public Company getCompany(long id) throws CouponSystemException {
		Connection con = ConnectionPool.getInstance().getConnection();
		String sql = "SELECT * FROM Company WHERE ID = " + id;
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {
			ResultSet rs = pstmt.executeQuery();
			Company comapany = new Company();
			while (rs.next()) {
				comapany.setId(id);
				comapany.setCompName(rs.getString(2));
				comapany.setPassword(rs.getString(3));
				comapany.setEmail(rs.getString(4));
			}
			return comapany;

		} catch (SQLException e) {
			throw new CouponSystemException("reading company failed", e);
		} finally {
			ConnectionPool.getInstance().returnConnection(con);
		}
	}

	/**
	 * reads all of the companies from the database.
	 * 
	 * @return A Collection<Company> with all of the companies from the
	 *         database.
	 * 
	 * @throws CouponSystemException
	 *             if it fails to read the companies from the database.
	 */

	@Override
	public Collection<Company> getAllCompanies() throws CouponSystemException {
		String sql = "SELECT ID FROM Company";
		List<Company> companies = new ArrayList<>();
		Connection con = ConnectionPool.getInstance().getConnection();
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {

			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				long id = rs.getLong(1);
				Company company = getCompany(id);
				companies.add(company);
			}
		} catch (SQLException e) {
			throw new CouponSystemException("getting company failed", e);
		} finally {
			ConnectionPool.getInstance().returnConnection(con);
		}

		return companies;
	}

	/**
	 * reads all of the coupons of a specific company from the database.
	 * 
	 * @param c
	 *            A company type object
	 * @return A Collection<Coupon> with all of the company's coupons
	 * @throws CouponSystemException
	 *             if it fails to read the company coupons
	 */
	@Override
	public Collection<Coupon> getCompanyCoupons(Company c) throws CouponSystemException {
		Collection<Coupon> coupons = new HashSet<>();
		String sql1 = "SELECT COUPON_ID FROM Company_Coupon WHERE COMP_ID = ?";
		String sql2 = "SELECT * FROM Coupon WHERE ID= ?";
		Connection con = ConnectionPool.getInstance().getConnection();
		try (PreparedStatement pstmt1 = con.prepareStatement(sql1);
				PreparedStatement pstmt2 = con.prepareStatement(sql2);) {
			pstmt1.setLong(1, c.getId());
			ResultSet rs = pstmt1.executeQuery();
			Set<Long> couponIds = new HashSet<>();
			while (rs.next()) {
				couponIds.add(rs.getLong(1));
			}
			for (long couponId : couponIds) {
				pstmt2.setLong(1, couponId);
				ResultSet rs2 = pstmt2.executeQuery();
				Coupon coupon = new Coupon();
				while (rs2.next()) {
					coupon.setId(couponId);
					coupon.setTitle(rs2.getString(2));
					coupon.setStartDate(rs2.getDate(3));
					coupon.setEndDate(rs2.getDate(4));
					coupon.setAmount(rs2.getInt(5));
					coupon.setType(CouponType.valueOf(rs2.getString(6)));
					coupon.setMessage(rs2.getString(7));
					coupon.setPrice(rs2.getDouble(8));
					coupon.setImage(rs2.getString(9));

					coupons.add(coupon);
				}
			}
		} catch (SQLException e) {
			throw new CouponSystemException("reading company coupons failed", e);
		} finally {
			ConnectionPool.getInstance().returnConnection(con);
		}

		return coupons;
	}

	/**
	 * reads all of the company's coupons which their price is under a given
	 * price
	 * 
	 * @param company
	 *            A company type object
	 * @param price
	 *            A coupon price
	 * @return A Collection<Coupon> with all of the company's coupons
	 * @throws CouponSystemException
	 *             if it fails to read the company's coupons from the database
	 */
	public Collection<Coupon> getCompanyCouponsByPrice(Company company, double price) throws CouponSystemException {
		List<Long> couponIds = new ArrayList<>();
		List<Coupon> coupons = new ArrayList<>();
		String sql1 = "SELECT COUPON_ID FROM Company_Coupon WHERE COMP_ID=?";
		String sql = "SELECT * FROM COUPON WHERE ID=? AND PRICE<=?";

		Connection con = ConnectionPool.getInstance().getConnection();
		try (PreparedStatement pstmt1 = con.prepareStatement(sql1);
				PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt1.setLong(1, company.getId());
			ResultSet rs1 = pstmt1.executeQuery();
			while (rs1.next()) {
				couponIds.add(rs1.getLong(1));
			}

			for (Long couponId : couponIds) {
				pstmt.setLong(1, couponId);
				pstmt.setDouble(2, price);
				ResultSet rs = pstmt.executeQuery();

				while (rs.next()) {
					Coupon coupon = new Coupon();
					coupon.setId(rs.getLong(1));
					coupon.setTitle(rs.getString(2));
					coupon.setStartDate(rs.getDate(3));
					coupon.setEndDate(rs.getDate(4));
					coupon.setAmount(rs.getInt(5));
					coupon.setType(CouponType.valueOf(rs.getString(6)));
					coupon.setMessage(rs.getString(7));
					coupon.setPrice(rs.getFloat(8));
					coupon.setImage(rs.getString(9));

					coupons.add(coupon);
				}

			}
		} catch (SQLException e) {
			throw new CouponSystemException("getting coupons by type failed", e);
		} finally {

			ConnectionPool.getInstance().returnConnection(con);
		}

		return coupons;

	}

	/**
	 * reads all of the company's coupons from a given type
	 * 
	 * @param company
	 *            A company type object
	 * @param type
	 *            A CouponType type object a customer type object
	 * @return A Collection<Coupon> with all of the company's coupons
	 * @throws CouponSystemException
	 *             if it fails to read the company's coupons from the database
	 */
	public Collection<Coupon> getCompanyCouponsByType(Company company, CouponType type) throws CouponSystemException {
		Set<Long> couponIds = new HashSet<>();
		Set<Coupon> typedCoupons = new HashSet<>();
		String sql1 = "SELECT COUPON_ID FROM Company_Coupon WHERE COMP_ID= ?";
		String sql2 = "SELECT * FROM Coupon WHERE ID= ? AND TYPE=?";
		Connection con = ConnectionPool.getInstance().getConnection();
		try (PreparedStatement pstmt1 = con.prepareStatement(sql1);
				PreparedStatement pstmt2 = con.prepareStatement(sql2);) {

			pstmt1.setLong(1, company.getId());
			ResultSet rs1 = pstmt1.executeQuery();
			while (rs1.next()) {
				couponIds.add(rs1.getLong(1));
			}
			for (Long couponId : couponIds) {
				pstmt2.setLong(1, couponId);
				pstmt2.setString(2, type.toString());
				ResultSet rs2 = pstmt2.executeQuery();
				while (rs2.next()) {
					Coupon c = new Coupon();
					c.setId(rs2.getLong(1));
					c.setTitle(rs2.getString(2));
					c.setStartDate(rs2.getDate(3));
					c.setEndDate(rs2.getDate(4));
					c.setAmount(rs2.getInt(5));
					c.setType(CouponType.valueOf(rs2.getString(6)));
					c.setMessage(rs2.getString(7));
					c.setPrice(rs2.getDouble(8));
					c.setImage(rs2.getString(9));

					typedCoupons.add(c);

				}
			}

		} catch (SQLException e) {
			throw new CouponSystemException("an error occured while reading the coupons of: " + company.getCompName()
					+ " from the type: " + type, e);
		}

		finally {
			ConnectionPool.getInstance().returnConnection(con);
		}
		return typedCoupons;

	}

	/**
	 * receives a company account details and try to login
	 * 
	 * @param compName
	 *            A company name.
	 * @param password
	 *            A company password.
	 * @return true if the login was successful - the name and password are
	 *         matching each other in the database. false otherwise.
	 * @throws LoginException
	 *             if the name and password aren't match.
	 * @throws CouponSystemException
	 *             if it fails to verify the name and password in the database.
	 * 
	 */

	@Override
	public boolean login(String compName, String password) throws SQLException, CouponSystemException {
		boolean ok = false;
		Connection con = ConnectionPool.getInstance().getConnection();
		String sql = "SELECT PASSWORD FROM Company WHERE COMP_NAME=? AND PASSWORD=?";
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setString(1, compName);
			pstmt.setString(2, password);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				ok = true;
			}

			if (ok == false) {
				throw new LoginException("login for: " + compName + " failed. user name or password are incorrect");
			}

		} catch (SQLException e) {
			throw new SQLException("login failed", e);
		} finally {
			ConnectionPool.getInstance().returnConnection(con);
		}
		return ok;
	}

	/**
	 * gets a company ID match to for a given company name from the database.
	 * 
	 * @param name
	 *            A company name
	 * @return A long type object represents the company's ID
	 * @throws CouponSystemException
	 *             if it fails to get the ID from the database.
	 */
	public long getIdForName(String name) throws CouponSystemException {
		String sql = "SELECT ID FROM Company WHERE COMP_NAME=?";
		Connection con = ConnectionPool.getInstance().getConnection();
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setString(1, name);
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			long id = rs.getLong(1);

			return id;
		} catch (SQLException e) {
			throw new CouponSystemException("an error occured while trying to read a company's id.", e);
		} finally {
			ConnectionPool.getInstance().returnConnection(con);
		}
	}

	/**
	 * checks whether a company name is already exists in the database or not.
	 * 
	 * @param companyName
	 *            A company name
	 * @return true if the name is not exist in the database. false otherwise.
	 * @throws CouponSystemException
	 *             if it fails to check for the name in the database.
	 */
	public boolean checkUniqueName(String companyName) throws CouponSystemException {
		boolean ok = true;
		Connection con = ConnectionPool.getInstance().getConnection();
		String sql = "SELECT * FROM Company WHERE COMP_NAME=?";
		try (PreparedStatement pstmt = con.prepareStatement(sql)) {
			pstmt.setString(1, companyName);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				ok = false;
			}

		} catch (SQLException e) {
			throw new CouponSystemException("an error occured while trying to check for a unique name in the database",
					e);

		} finally {
			ConnectionPool.getInstance().returnConnection(con);
		}
		return ok;
	}

	/**
	 * inserts a coupon type object details to the Company_Coupon join table in
	 * the database.
	 * 
	 * @param company
	 *            A company type object
	 * @param coupon
	 *            A coupon type object
	 * @throws CouponSystemException
	 *             if it fails to insert the values to the table.
	 */
	public void addCouponToCompany(Company company, Coupon coupon) throws CouponSystemException {

		String sql = "INSERT INTO Company_Coupon values(?,?)";
		Connection con = ConnectionPool.getInstance().getConnection();
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setLong(1, company.getId());
			pstmt.setLong(2, coupon.getId());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new CouponSystemException("creating coupon failed", e);

		} finally {
			ConnectionPool.getInstance().returnConnection(con);
		}
	}

	/**
	 * deletes a coupon type object details from the Company_Coupon join table
	 * in the database.
	 * 
	 * @param coupon
	 *            A coupon type object
	 * @throws CouponSystemException
	 *             if it fails to delete the values from the table.
	 */
	public void removeCouponFromCompany(Coupon coupon) throws CouponSystemException {
		String sql = "DELETE FROM Company_Coupon WHERE COUPON_ID=?";
		Connection con = ConnectionPool.getInstance().getConnection();
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setLong(1, coupon.getId());
			pstmt.executeUpdate();

		} catch (SQLException e) {
			throw new CouponSystemException("removing coupon failed.", e);

		} finally {
			ConnectionPool.getInstance().returnConnection(con);
		}

	}

}
