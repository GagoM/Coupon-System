package core.daoClasses;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import core.Exceptions.CouponSystemException;
import core.Exceptions.UniqueNameException;
import core.connections.ConnectionPool;
import core.daoInterfaces.CouponDao;
import core.javaBeans.Coupon;
import core.javaBeans.CouponType;

public class CouponDBDAO implements CouponDao {
	/**
	 * creates a new coupon in the database
	 * 
	 * @param c
	 *            A coupon type object
	 * @throws UniqueNameException
	 *             if the coupon's name is already exists in the database
	 * @throws CouponSystemException
	 *             if it fails to create to coupon in the database
	 * 
	 *
	 */
	@Override
	public void createCoupon(Coupon c) throws CouponSystemException {
		String sql = "INSERT INTO Coupon (TITLE, START_DATE, END_DATE, AMOUNT, TYPE, MESSAGE, PRICE, IMAGE) values(?,?,?,?,?,?,?,?)";
		String sql2 = "SELECT ID FROM Coupon WHERE TITLE = ?";
		if (checkUniqueName(c.getTitle()) == true) {
			Connection con = ConnectionPool.getInstance().getConnection();
			try (PreparedStatement pstmt = con.prepareStatement(sql);
					PreparedStatement pstmt2 = con.prepareStatement(sql2)) {
				pstmt.setString(1, c.getTitle());
				pstmt.setDate(2, c.getStartDate());
				pstmt.setDate(3, c.getEndDate());
				pstmt.setInt(4, c.getAmount());
				pstmt.setString(5, c.getType().name());
				pstmt.setString(6, c.getMessage());
				pstmt.setDouble(7, c.getPrice());
				pstmt.setString(8, c.getImage());
				pstmt.executeUpdate();

				pstmt2.setString(1, c.getTitle());
				ResultSet rs2 = pstmt2.executeQuery();
				rs2.next();
				long id = rs2.getLong(1);
				c.setId(id);

			} catch (Exception e) {
				throw new CouponSystemException("failed to create coupon", e);
			} finally {

				ConnectionPool.getInstance().returnConnection(con);
			}
		} else {
			throw new UniqueNameException("Coupon name is already taken by another coupon.");
		}
	}

	/**
	 * removes a coupon from the database
	 * 
	 * @param c
	 *            A coupon type object
	 * @throws CouponSystemException
	 *             if it fails to create the coupon in the database
	 */
	@Override
	public void removeCoupon(Coupon c) throws CouponSystemException {
		c.setId(getIdForName(c.getTitle()));
		String sql = "DELETE FROM Coupon WHERE id=" + c.getId();
		Connection con = ConnectionPool.getInstance().getConnection();

		try (PreparedStatement pstmt = con.prepareStatement(sql);) {

			pstmt.executeUpdate();

		} catch (SQLException e) {
			throw new CouponSystemException("removing coupon failed", e);
		} finally {
			ConnectionPool.getInstance().returnConnection(con);
		}

	}

	/**
	 * updates the price and the end_date of an existing coupon in the database.
	 * 
	 * @param coupon
	 *            A coupon type object
	 * @throws CouponSystemException
	 *             if it fails to update the coupon in the database
	 * 
	 */
	@Override
	public void updateCoupon(Coupon coupon) throws CouponSystemException {
		coupon.setId(getIdForName(coupon.getTitle()));
		Connection con = ConnectionPool.getInstance().getConnection();
		String sql = "UPDATE Coupon SET END_DATE=?, PRICE=? WHERE ID=?";

		try (PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setDate(1, coupon.getEndDate());
			pstmt.setDouble(2, coupon.getPrice());
			pstmt.setLong(3, coupon.getId());
			pstmt.executeUpdate();
			System.out.println("Coupon: " + coupon.getTitle() + " was updated");
		} catch (SQLException e) {
			throw new CouponSystemException("updating Company failed", e);
		} finally {
			ConnectionPool.getInstance().returnConnection(con);
		}

	}

	/**
	 * reads all of the coupons exists in the database
	 * 
	 * @return A Collection<Coupon> with all of the coupons from the database
	 * @throws CouponSystemException
	 *             if it fails to read the coupons from the database
	 */
	@Override
	public Collection<Coupon> getAllCoupon() throws CouponSystemException {
		Connection con = ConnectionPool.getInstance().getConnection();
		String sql = "SELECT * FROM Coupon";
		Set<Coupon> coupons = new HashSet<>();
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {

			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				Coupon c = new Coupon();
				c.setId(rs.getLong(1));
				c.setTitle(rs.getString(2));
				c.setStartDate(rs.getDate(3));
				c.setEndDate(rs.getDate(4));
				c.setAmount(rs.getInt(5));
				c.setType(CouponType.valueOf(rs.getString(6)));
				c.setMessage(rs.getString(7));
				c.setPrice(rs.getFloat(8));
				c.setImage(rs.getString(9));

				coupons.add(c);
			}
			return coupons;
		} catch (SQLException e) {
			throw new CouponSystemException("getting coupons failed", e);
		} finally {
			ConnectionPool.getInstance().returnConnection(con);
		}

	}

	/**
	 * reads all of the coupons from the database of a specific type
	 * 
	 * @param c
	 *            A CouponType type object
	 * @return A Collection<Coupon> with all of the selected type coupons from
	 *         the database
	 */
	@Override
	public Collection<Coupon> getCouponByType(CouponType c) throws CouponSystemException {
		List<Coupon> coupons = new ArrayList<>();
		String sql = "SELECT * FROM COUPON WHERE TYPE = ?";

		Connection con = ConnectionPool.getInstance().getConnection();
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setString(1, c.name());
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				Coupon coupon = new Coupon();
				coupon.setId(rs.getLong(1));
				coupon.setTitle(rs.getString(2));
				coupon.setStartDate(rs.getDate(3));
				coupon.setEndDate(rs.getDate(4));
				coupon.setAmount(rs.getInt(5));
				coupon.setType(CouponType.valueOf(rs.getString(6)));
				coupon.setMessage(rs.getString(7));
				coupon.setPrice(rs.getFloat(8));
				coupon.setImage(rs.getString(9));

				coupons.add(coupon);

			}
		} catch (SQLException e) {
			throw new CouponSystemException("getting coupons by type failed", e);
		} finally {

			ConnectionPool.getInstance().returnConnection(con);
		}

		return coupons;
	}

	/**
	 * reads a specific coupon from the database given its ID
	 * 
	 * @param id
	 *            a coupon's ID
	 * @return A coupon type object
	 * @throws CouponSystemException
	 *             if it fails to read the coupon from the database
	 */
	public Coupon readCoupon(long id) throws CouponSystemException {
		Connection con = ConnectionPool.getInstance().getConnection();
		String sql = "SELECT * FROM Coupon WHERE ID=" + id;
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {

			ResultSet rs = pstmt.executeQuery();
			Coupon coupon = new Coupon();
			while (rs.next()) {
				coupon.setId(rs.getLong(1));
				coupon.setTitle(rs.getString(2));
				coupon.setStartDate(rs.getDate(3));
				coupon.setEndDate(rs.getDate(4));
				coupon.setAmount(rs.getInt(5));
				coupon.setType(CouponType.valueOf(rs.getString(6)));
				coupon.setMessage(rs.getString(7));
				coupon.setPrice(rs.getFloat(8));
				coupon.setImage(rs.getString(9));

			}
			return coupon;
		} catch (SQLException e) {

			throw new CouponSystemException("reading coupon failed", e);
		} finally {
			ConnectionPool.getInstance().returnConnection(con);
		}
	}

	/**
	 * checks in the database if the amount of the specific coupon if bigger
	 * than zero
	 * 
	 * @param coupon
	 *            A coupon type object
	 * @return true if the coupon's amount is bigger than zero, false otherwise
	 * @throws CouponSystemException
	 *             if it fails to check the coupon's amount in the database
	 */
	public boolean checkIfCouponInStock(Coupon coupon) throws CouponSystemException {

		boolean inStock = false;
		Connection con = ConnectionPool.getInstance().getConnection();
		String sql = "SELECT * FROM Coupon WHERE ID=?";
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setLong(1, getIdForName(coupon.getTitle()));
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			long couponAmount = rs.getInt(5);
			if (couponAmount > 0) {
				inStock = true;
			}
		} catch (SQLException e) {
			throw new CouponSystemException("an error occured for checking if coupon is in stock", e);
		} finally {

			ConnectionPool.getInstance().returnConnection(con);
		}
		return inStock;
	}

	/**
	 * checks whether the given coupon name is already exists in the database or
	 * not
	 * 
	 * @param CouponName
	 *            A coupon's name
	 * @return true if the name isn't exists in the database, false otherwise
	 * @throws CouponSystemException
	 *             if it fails to check the coupon's name in the database
	 */
	public boolean checkUniqueName(String CouponName) throws CouponSystemException {
		boolean ok = true;
		Connection con = ConnectionPool.getInstance().getConnection();
		String sql = "SELECT * FROM Coupon WHERE TITLE=?";
		try (PreparedStatement pstmt = con.prepareStatement(sql)) {
			pstmt.setString(1, CouponName);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				ok = false;
			}

		} catch (SQLException e) {
			throw new CouponSystemException("an error occured for checking unique name", e);

		}
		return ok;
	}

	/**
	 * gets an ID of a coupon given its name
	 * 
	 * @param name
	 *            A coupon's name
	 * @return A long type object represents a coupon ID
	 * @throws CouponSystemException
	 *             if it fails to check for the coupon's ID in the database.
	 */
	public long getIdForName(String name) throws CouponSystemException {
		Connection con = ConnectionPool.getInstance().getConnection();
		String sql = "SELECT ID FROM Coupon WHERE TITLE=?";
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setString(1, name);
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			long id = rs.getLong(1);
			return id;
		} catch (SQLException e) {

			throw new CouponSystemException("an error occured for reading a coupon's id.", e);
		}
	}

}