package core.daoClasses;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import core.Exceptions.CouponSystemException;
import core.Exceptions.InvalidCouponException;
import core.Exceptions.LoginException;
import core.Exceptions.UniqueNameException;
import core.connections.ConnectionPool;
import core.daoInterfaces.CustomerDao;
import core.javaBeans.Coupon;
import core.javaBeans.CouponType;
import core.javaBeans.Customer;

public class CustomerDBDAO implements CustomerDao {

	CouponDBDAO couponDao = new CouponDBDAO();

	/**
	 * creates a new customer in the database @param c a customer type
	 * object @throws UniqueNameException if the customer name is already exists
	 * in the database
	 * 
	 * @throws CouponSystemException
	 *             if it fails to create the customer in the database
	 */
	@Override
	public void createCustomer(Customer c) throws CouponSystemException {

		if (checkUniqueName(c.getCustName()) == true) {
			String sql = "INSERT INTO Customer (CUST_NAME,PASSWORD) values(?,?)";

			Connection con = ConnectionPool.getInstance().getConnection();

			try (PreparedStatement pstmt = con.prepareStatement(sql)) {

				pstmt.setString(1, c.getCustName());
				pstmt.setString(2, c.getPassword());
				pstmt.executeUpdate();
				System.out.println("customer: " + c.getCustName() + " created Successfully");
				c.setId(getIdForName(c.getCustName()));
			} catch (Exception e) {
				throw new CouponSystemException("Creating customer failed", e);
			} finally {

				ConnectionPool.getInstance().returnConnection(con);
			}
		} else {
			throw new UniqueNameException("the customer name is already exists in the database");
		}
	}

	/**
	 * deletes a given customer from the database, include his purchased coupons
	 * 
	 * @param c
	 *            A customer type object
	 * @throws CouponSystemException
	 *             if it fails to delete the customer from the database
	 */
	@Override
	public void removeCustomer(Customer c) throws CouponSystemException {
		c.setId(getIdForName(c.getCustName()));
		String sql1 = "DELETE FROM Customer WHERE ID=?";
		String sql2 = "DELETE FROM Customer_Coupon WHERE CUST_ID=?";
		Connection con = ConnectionPool.getInstance().getConnection();

		try (PreparedStatement pstmt1 = con.prepareStatement(sql1);
				PreparedStatement pstmt2 = con.prepareStatement(sql2);) {

			pstmt1.setLong(1, c.getId());
			pstmt1.executeUpdate();
			pstmt2.setLong(1, c.getId());
			pstmt2.executeUpdate();

			System.out.println("customer: " + c.getCustName() + " removed Successfully");

		} catch (SQLException e) {
			throw new CouponSystemException("removing Customer failed", e);
		} finally {
			ConnectionPool.getInstance().returnConnection(con);
		}
	}

	/**
	 * updates an existing customer details in the database, besides his name
	 * 
	 * @param c
	 *            A customer type object
	 * @throws CouponSystemException
	 *             if it fails to update the customer in the database
	 */
	@Override
	public void updateCustomer(Customer c) throws CouponSystemException {
		c.setId(getIdForName(c.getCustName()));

		Connection con = ConnectionPool.getInstance().getConnection();
		String sql = "UPDATE Customer SET PASSWORD=? WHERE ID=?";
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setString(1, c.getPassword());
			pstmt.setLong(2, c.getId());
			pstmt.executeUpdate();

			System.out.println("customer: " + c.getCustName() + " updated Successfully");

		} catch (SQLException e) {
			throw new CouponSystemException("updating Customer failed", e);
		} finally {
			ConnectionPool.getInstance().returnConnection(con);
		}

	}

	/**
	 * reads a specific customer from the database given its ID
	 * 
	 * @param id
	 *            a customer id
	 * @return A customer type object
	 * @throws CouponSystemException
	 *             if it fails to read the customer from the database
	 */
	public Customer getCustomer(long id) throws CouponSystemException {
		Connection con = ConnectionPool.getInstance().getConnection();
		String sql = "SELECT * FROM Customer WHERE ID = ?";
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setLong(1, id);
			ResultSet rs = pstmt.executeQuery();
			Customer customer = new Customer();
			while (rs.next()) {
				customer.setId(id);
				customer.setCustName(rs.getString(2));
				customer.setPassword(rs.getString(3));
			}
			return customer;

		} catch (SQLException e) {
			throw new CouponSystemException("getting customer failed.", e);
		} finally {
			ConnectionPool.getInstance().returnConnection(con);
		}

	}

	/**
	 * reads all of the customers from the database
	 * 
	 * @return A Collection<Customer> with all of the customers existing in the
	 *         database
	 * @throws CouponSystemException
	 *             if it fails to read the customers from the database
	 */
	@Override
	public Collection<Customer> getAllCustomer() throws CouponSystemException {
		String sql = "SELECT ID FROM Customer";
		Set<Long> customerIds = new HashSet<>();
		List<Customer> customers = new ArrayList<>();
		Connection con = ConnectionPool.getInstance().getConnection();
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {

			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				long id = rs.getLong(1);
				customerIds.add(id);
			}
			for (long customerId : customerIds) {
				Customer customer = getCustomer(customerId);
				customers.add(customer);
			}
		} catch (SQLException e) {
			throw new CouponSystemException("getting all customers failed", e);
		} finally {
			ConnectionPool.getInstance().returnConnection(con);
		}

		return customers;
	}

	/**
	 * reads all all of the coupons that purchased by a specific customer
	 * 
	 * @param c
	 *            a customer type object
	 * @return A Collection<Coupon> with all of the customer's coupons
	 * @throws CouponSystemException
	 *             if it fails to read the customer's coupons from the database
	 */
	@Override
	public Collection<Coupon> getCustomerCoupons(Customer c) throws CouponSystemException {
		Collection<Coupon> coupons = new HashSet<>();
		String sql1 = "SELECT COUPON_ID FROM Customer_Coupon WHERE Cust_ID = ?";
		String sql2 = "SELECT * FROM Coupon WHERE ID= ?";
		Connection con = ConnectionPool.getInstance().getConnection();
		try (PreparedStatement pstmt1 = con.prepareStatement(sql1);
				PreparedStatement pstmt2 = con.prepareStatement(sql2);) {
			pstmt1.setLong(1, c.getId());
			ResultSet rs = pstmt1.executeQuery();
			Set<Long> couponIds = new HashSet<>();
			while (rs.next()) {
				couponIds.add(rs.getLong(1));
			}
			for (Long couponId : couponIds) {
				pstmt2.setLong(1, couponId);
				ResultSet rs2 = pstmt2.executeQuery();
				Coupon coupon = new Coupon();
				while (rs2.next()) {
					coupon.setId(rs2.getLong(1));
					coupon.setTitle(rs2.getString(2));
					coupon.setStartDate(rs2.getDate(3));
					coupon.setEndDate(rs2.getDate(4));
					coupon.setAmount(rs2.getInt(5));
					coupon.setType(CouponType.valueOf(rs2.getString(6)));
					coupon.setMessage(rs2.getString(7));
					coupon.setPrice(rs2.getDouble(8));
					coupon.setImage(rs2.getString(9));

					coupons.add(coupon);
				}
			}
		} catch (SQLException e) {
			throw new CouponSystemException("reading customer coupons failed", e);
		} finally {
			ConnectionPool.getInstance().returnConnection(con);
		}
		return coupons;
	}

	/**
	 * reads all all of the coupons from a given type that purchased by a
	 * specific customer
	 * 
	 * @param customer
	 * @param type
	 *            A CouponType type object a customer type object
	 * @return A Collection<Coupon> with all of the given typed customer's
	 *         coupons
	 * @throws CouponSystemException
	 *             if it fails to read the customer's coupons from the database
	 */
	public Collection<Coupon> getCustomerCouponsByType(Customer customer, CouponType type)
			throws CouponSystemException {
		Set<Long> couponIds = new HashSet<>();
		Set<Coupon> typedCoupons = new HashSet<>();
		String sql1 = "SELECT COUPON_ID FROM Customer_Coupon WHERE CUST_ID = ?";
		String sql2 = "SELECT * FROM Coupon WHERE ID= ? AND TYPE=?";
		Connection con = ConnectionPool.getInstance().getConnection();
		try (PreparedStatement pstmt1 = con.prepareStatement(sql1);
				PreparedStatement pstmt2 = con.prepareStatement(sql2);) {

			pstmt1.setLong(1, customer.getId());
			ResultSet rs1 = pstmt1.executeQuery();
			while (rs1.next()) {
				couponIds.add(rs1.getLong(1));
			}
			for (Long couponId : couponIds) {
				pstmt2.setLong(1, couponId);
				pstmt2.setString(2, type.toString());
				ResultSet rs2 = pstmt2.executeQuery();
				while (rs2.next()) {
					Coupon c = new Coupon();
					c.setId(rs2.getLong(1));
					c.setTitle(rs2.getString(2));
					c.setStartDate(rs2.getDate(3));
					c.setEndDate(rs2.getDate(4));
					c.setAmount(rs2.getInt(5));
					c.setType(CouponType.valueOf(rs2.getString(6)));
					c.setMessage(rs2.getString(7));
					c.setPrice(rs2.getDouble(8));
					c.setImage(rs2.getString(9));

					typedCoupons.add(c);

				}
			}

		} catch (SQLException e) {
			throw new CouponSystemException("an error occured while reading the coupons of: " + customer.getCustName()
					+ " from the type: " + type, e);
		}

		finally {
			ConnectionPool.getInstance().returnConnection(con);
		}
		return typedCoupons;

	}

	/**
	 * searches the database for the customer's coupons which their price is
	 * lower than a given price
	 * 
	 * @param customer
	 *            A customer type object
	 * @param price
	 *            A coupon price
	 * @return Collection<Coupon> with all of the customer's coupons under the
	 *         given price
	 * @throws CouponSystemException
	 *             if it fails to read the coupons from the database
	 */
	public Collection<Coupon> getCustomerCouponsByPrice(Customer customer, double price) throws CouponSystemException {
		List<Long> couponIds = new ArrayList<>();
		List<Coupon> coupons = new ArrayList<>();
		String sql1 = "SELECT COUPON_ID FROM Customer_Coupon WHERE CUST_ID=?";
		String sql = "SELECT * FROM COUPON WHERE ID=? AND PRICE<=?";

		Connection con = ConnectionPool.getInstance().getConnection();
		try (PreparedStatement pstmt1 = con.prepareStatement(sql1);
				PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt1.setLong(1, customer.getId());
			ResultSet rs1 = pstmt1.executeQuery();
			while (rs1.next()) {
				couponIds.add(rs1.getLong(1));
			}

			for (Long couponId : couponIds) {
				pstmt.setLong(1, couponId);
				pstmt.setDouble(2, price);
				ResultSet rs = pstmt.executeQuery();

				while (rs.next()) {
					Coupon coupon = new Coupon();
					coupon.setId(rs.getLong(1));
					coupon.setTitle(rs.getString(2));
					coupon.setStartDate(rs.getDate(3));
					coupon.setEndDate(rs.getDate(4));
					coupon.setAmount(rs.getInt(5));
					coupon.setType(CouponType.valueOf(rs.getString(6)));
					coupon.setMessage(rs.getString(7));
					coupon.setPrice(rs.getFloat(8));
					coupon.setImage(rs.getString(9));

					coupons.add(coupon);
				}

			}
		} catch (SQLException e) {
			throw new CouponSystemException("getting coupons by type failed", e);
		} finally {

			ConnectionPool.getInstance().returnConnection(con);
		}

		return coupons;

	}

	/**
	 * receives a customer account details and try to login
	 * 
	 * @param custName
	 *            A customer's name.
	 * @param password
	 *            A customer's password.
	 * @return true if the login was successful - the name and password are
	 *         matching each other in the database. false otherwise.
	 * @throws LoginException
	 *             if the name and password aren't match.
	 * @throws CouponSystemException
	 *             if it fails to verify the name and password in the database.
	 * 
	 */

	@Override
	public boolean login(String custName, String password) throws SQLException, CouponSystemException {
		boolean ok = false;
		Connection con = ConnectionPool.getInstance().getConnection();
		String sql = "SELECT PASSWORD FROM Customer WHERE CUST_NAME=? AND PASSWORD=?";
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setString(1, custName);
			pstmt.setString(2, password);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				ok = true;
				System.out.println("login for: " + custName + " succeeded");
			}

			if (ok == false) {
				throw new LoginException("login for: " + custName + " failed. user name or password are incorrect.");
			}

		} catch (

		SQLException e) {
			throw new CouponSystemException("login failed", e);
		} finally {
			ConnectionPool.getInstance().returnConnection(con);
		}
		return ok;
	}

	/**
	 * gets a customer ID match to a given customer name from the database.
	 * 
	 * @param name
	 *            A customer name
	 * @return A long type object represents the company's ID
	 * @throws CouponSystemException
	 *             if it fails to get the ID from the database.
	 */

	public long getIdForName(String name) throws CouponSystemException {
		Connection con = ConnectionPool.getInstance().getConnection();
		String sql = "SELECT ID FROM Customer WHERE CUST_NAME=?";
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setString(1, name);
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			long id = rs.getLong(1);
			return id;
		} catch (SQLException e) {
			throw new CouponSystemException("an error occuerd while trying to read an customer's id from the database.",
					e);
		} finally {
			ConnectionPool.getInstance().returnConnection(con);

		}
	}

	/**
	 * checks whether a given name is already exists in the database or not
	 * 
	 * @param name
	 *            a customer name
	 * @return true if the name isn't exist in the database, false otherwise
	 * @throws CouponSystemException
	 *             if it fails to check for the name in the database
	 */
	public boolean checkUniqueName(String name) throws CouponSystemException {
		boolean ok = true;
		Connection con = ConnectionPool.getInstance().getConnection();
		String sql = "SELECT * FROM Customer WHERE CUST_NAME=?";
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setString(1, name);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				ok = false;
			}

		} catch (SQLException e) {
			throw new CouponSystemException("an error occured while trying to check for a unique name in the database.",
					e);
		} finally {
			ConnectionPool.getInstance().returnConnection(con);
		}
		return ok;
	}

	/**
	 * adds a new coupon to a specific customer in the customer_coupon join
	 * table, and updates the coupon's amount accordingly
	 * 
	 * @param customer
	 *            A customer type object
	 * @param coupon
	 *            A coupon type object
	 * @throws InvalidCouponException
	 *             if the coupon amount is zero or if the coupon's end date has
	 *             been expired
	 * @throws CouponSystemException
	 *             if it fails to add the coupon to the table
	 */
	public void addCouponToCustomer(Customer customer, Coupon coupon) throws CouponSystemException {
		Date date = Calendar.getInstance().getTime();
		if (couponDao.checkIfCouponInStock(coupon) == true && coupon.getEndDate().after(date)
				&& couponPurchasedAlready(customer.getId(), coupon.getId()) == false) {

			String sql = "INSERT INTO Customer_Coupon values(?,?)";
			String sql2 = "UPDATE Coupon SET AMOUNT = AMOUNT-1 WHERE ID=?";

			Connection con = ConnectionPool.getInstance().getConnection();

			try (PreparedStatement pstmt = con.prepareStatement(sql);
					PreparedStatement pstmt2 = con.prepareStatement(sql2)) {
				pstmt.setLong(1, customer.getId());
				pstmt.setLong(2, coupon.getId());
				pstmt.executeUpdate();

				pstmt2.setLong(1, coupon.getId());
				pstmt2.executeUpdate();
			} catch (SQLException e) {
				throw new CouponSystemException("purchasing coupon failed.", e);
			} finally {
				ConnectionPool.getInstance().returnConnection(con);
			}
		} else {
			throw new InvalidCouponException(
					"the desired coupon cannot be purchased, since it is out of stock or its end date expired, or the customer already bought it before.");
		}
	}

	/**
	 * deletes a coupon from a specific customer in the customer_coupon join
	 * table
	 * 
	 * @param coupon
	 *            A coupon type object
	 * @throws CouponSystemException
	 *             if it fails to delete the coupon from the table
	 */
	public void removeCouponFromCustomer(Coupon coupon) throws CouponSystemException {
		String sql = "DELETE FROM Customer_Coupon WHERE COUPON_ID=?";
		Connection con = ConnectionPool.getInstance().getConnection();
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setLong(1, coupon.getId());
			pstmt.executeUpdate();

		} catch (SQLException e) {
			throw new CouponSystemException("an error occured while trying to remove coupon from customer database", e);
		} finally {
			ConnectionPool.getInstance().returnConnection(con);
		}
	}

	/**
	 * checks whether a given coupon was already purchased by a specific
	 * customer or not
	 * 
	 * @param customerId
	 *            A customer id
	 * @param couponId
	 *            A coupon id
	 * @return false if the coupon wasn't purchase by the customer before, true
	 *         otherwise
	 * @throws CouponSystemException
	 *             if it fails to check for the given coupon in the database
	 */
	public boolean couponPurchasedAlready(long customerId, long couponId) throws CouponSystemException {
		boolean ok = false;
		String sql = "SELECT * FROM Customer_Coupon WHERE CUST_ID=? AND COUPON_ID=?";
		Connection con = ConnectionPool.getInstance().getConnection();
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setLong(1, customerId);
			pstmt.setLong(2, couponId);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				ok = true;
			}

		} catch (SQLException e) {
			throw new CouponSystemException("an error occured while trying the check the customer's coupons", e);
		} finally {
			ConnectionPool.getInstance().returnConnection(con);
		}
		return ok;

	}
}