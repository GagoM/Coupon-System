package core.daoInterfaces;

import java.sql.SQLException;
import java.util.Collection;

import core.Exceptions.CouponSystemException;
import core.Exceptions.LoginException;
import core.Exceptions.UniqueNameException;
import core.javaBeans.Company;
import core.javaBeans.Coupon;

public interface CompanyDao {

	void createCompany(Company c) throws CouponSystemException, SQLException, UniqueNameException;

	void removeCompany(Company c) throws CouponSystemException;

	void updateCompany(Company c) throws CouponSystemException;

	Company getCompany(long id) throws CouponSystemException;

	Collection<Company> getAllCompanies() throws CouponSystemException;

	Collection<Coupon> getCompanyCoupons(Company c) throws CouponSystemException;

	boolean login(String compName, String password) throws CouponSystemException, SQLException, LoginException;
}
