package core.daoInterfaces;

import java.util.Collection;

import core.Exceptions.CouponSystemException;
import core.Exceptions.UniqueNameException;
import core.javaBeans.Coupon;
import core.javaBeans.CouponType;

public interface CouponDao {

	public void createCoupon(Coupon c) throws CouponSystemException, UniqueNameException;

	public void removeCoupon(Coupon c) throws CouponSystemException;

	public void updateCoupon(Coupon c) throws CouponSystemException;

	public Coupon readCoupon(long id) throws CouponSystemException;

	public Collection<Coupon> getAllCoupon() throws CouponSystemException;

	public Collection<Coupon> getCouponByType(CouponType c) throws CouponSystemException;

}
