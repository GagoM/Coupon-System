package core.daoInterfaces;

import java.sql.SQLException;
import java.util.Collection;

import core.Exceptions.CouponSystemException;
import core.Exceptions.LoginException;
import core.Exceptions.UniqueNameException;
import core.javaBeans.Coupon;
import core.javaBeans.Customer;

public interface CustomerDao {

	public void createCustomer(Customer c) throws CouponSystemException, UniqueNameException;

	public void removeCustomer(Customer c) throws CouponSystemException;

	public void updateCustomer(Customer c) throws CouponSystemException;

	public Customer getCustomer(long id) throws CouponSystemException;

	public Collection<Customer> getAllCustomer() throws CouponSystemException;

	public Collection<Coupon> getCustomerCoupons(Customer c) throws CouponSystemException;

	public boolean login(String custName, String password) throws CouponSystemException, SQLException, LoginException;
}
