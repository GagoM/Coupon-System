package core.facades;

import java.util.Collection;

import core.Exceptions.CouponSystemException;
import core.Exceptions.LoginException;
import core.Exceptions.UniqueNameException;
import core.couponSystemSingleton.ClientType;
import core.daoClasses.CompanyDBDAO;
import core.daoClasses.CustomerDBDAO;
import core.javaBeans.Company;
import core.javaBeans.Customer;

public class AdminFacade implements CouponClientFacade {

	private CompanyDBDAO companyDao = new CompanyDBDAO();
	private CustomerDBDAO customerDao = new CustomerDBDAO();

	public AdminFacade() {

	}

	/**
	 * creates a new company in the database
	 * 
	 * @param c
	 *            A company type object
	 * @throws UniqueNameException
	 *             if the company name is already exists in the database
	 * @throws CouponSystemException
	 *             if it fails to create the company in the database
	 * 
	 */
	public void createCompany(Company c) throws CouponSystemException, UniqueNameException {
		companyDao.createCompany(c);

	}

	/**
	 * deletes a given company from the database
	 * 
	 * @param c
	 *            A company type object
	 * @throws CouponSystemException
	 *             if it fails to delete the company from the database
	 */
	public void removeCompany(Company c) throws CouponSystemException {
		companyDao.removeCompany(c);
	}

	/**
	 * updates the price and the end_date of an existing company in the database
	 * 
	 * @param c
	 *            A company type object
	 * @throws CouponSystemException
	 *             if it fails to update the company from the database
	 */
	public void updateCompany(Company c) throws CouponSystemException {
		companyDao.updateCompany(c);
	}

	/**
	 * reads a company from the database given its ID
	 * 
	 * @param id
	 *            A company ID
	 * @return A company type object
	 * @throws CouponSystemException
	 *             if it fails to read the company from the database
	 */
	public Company readCompany(long id) throws CouponSystemException {
		return companyDao.getCompany(id);
	}

	/**
	 * reads all of the companies from the database
	 * 
	 * @return A Collection<Company> with all of the companies from the database
	 * @throws CouponSystemException
	 *             if it fails to read the companies from the database
	 */
	public Collection<Company> readAllCompanies() throws CouponSystemException {
		return companyDao.getAllCompanies();
	}

	/**
	 * creates a new customer in the database
	 * 
	 * @param c
	 *            A customer type object
	 * @throws UniqueNameException
	 *             if the customer's name is already exist in the database
	 * @throws CouponSystemException
	 *             if it fails to create the customer in the database
	 */
	public void createCustomer(Customer c) throws CouponSystemException, UniqueNameException {
		customerDao.createCustomer(c);
	}

	/**
	 * deletes a given customer from the database, including his purchased
	 * coupons
	 * 
	 * @param c
	 *            A customer type object
	 * @throws CouponSystemException
	 *             if it fails to delete the customer from the database
	 */

	public void removeCustomer(Customer c) throws CouponSystemException {
		customerDao.removeCustomer(c);
	}

	/**
	 * updates an existing customer details in the database, besides his name
	 * 
	 * @param c
	 *            A customer type object
	 * @throws CouponSystemException
	 *             if it fails to update the customer in the database
	 */

	public void updateCustomer(Customer c) throws CouponSystemException {
		customerDao.updateCustomer(c);
	}

	/**
	 * reads a specific customer from the database given its ID
	 * 
	 * @param id
	 *            a customer id
	 * @return A customer type object
	 * @throws CouponSystemException
	 *             if it fails to read the customer from the database
	 */

	public Customer readCustomer(long id) throws CouponSystemException {
		return customerDao.getCustomer(id);
	}

	/**
	 * reads all of the customers from the database
	 * 
	 * @return A Collection<Customer> with all of the customers existing in the
	 *         database
	 * @throws CouponSystemException
	 *             if it fails to read the customers from the database
	 */

	public Collection<Customer> readAllCustomer() throws CouponSystemException {
		return customerDao.getAllCustomer();
	}

	/**
	 * tries to login with the account details of an admin
	 * 
	 * @param userName
	 *            an admin user name
	 * @param password
	 *            an admin passowrd
	 * @param clientType
	 *            A clientType type object
	 * @return an admin facade instance
	 * @throws LoginException
	 *             if the user name and password aren't match
	 */
	@Override
	public AdminFacade login(String userName, String password, ClientType clientType) throws LoginException {
		if (userName.equals("admin") && password.equals("1234")) {
			return this;
		} else {
			throw new LoginException("login failed. user name or password are incorrect.");
		}
	}

}
