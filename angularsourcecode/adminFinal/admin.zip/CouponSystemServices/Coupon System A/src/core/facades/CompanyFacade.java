package core.facades;

import java.sql.SQLException;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import core.Exceptions.CouponSystemException;
import core.Exceptions.LoginException;
import core.Exceptions.UniqueNameException;
import core.couponSystemSingleton.ClientType;
import core.daoClasses.CompanyDBDAO;
import core.daoClasses.CouponDBDAO;
import core.daoClasses.CustomerDBDAO;
import core.javaBeans.Company;
import core.javaBeans.Coupon;
import core.javaBeans.CouponType;

public class CompanyFacade implements CouponClientFacade {
	private CompanyDBDAO companyDao = new CompanyDBDAO();
	private CustomerDBDAO customerDao = new CustomerDBDAO();
	private CouponDBDAO couponDao = new CouponDBDAO();
	private long CompanyId;

	public CompanyFacade() {
	}

	/**
	 * creates a new coupon in the database
	 * 
	 * @param coupon
	 *            A coupon type object
	 * @throws UniqueNameException
	 *             if the coupon's name is already exists in the database
	 * @throws CouponSystemException
	 *             if it fails to create to coupon in the database
	 * 
	 *
	 */
	public void createCoupon(Coupon coupon) throws CouponSystemException, UniqueNameException {

		couponDao.createCoupon(coupon);
		Company company = companyDao.getCompany(this.CompanyId);
		companyDao.addCouponToCompany(company, coupon);

	}

	/**
	 * removes a coupon from the database
	 * 
	 * @param coupon
	 *            A coupon type object
	 * @throws CouponSystemException
	 *             if it fails to create the coupon in the database
	 */

	public void removeCoupon(Coupon coupon) throws CouponSystemException {
		companyDao.removeCouponFromCompany(coupon);
		customerDao.removeCouponFromCustomer(coupon);
		couponDao.removeCoupon(coupon);
	}

	/**
	 * updates the price and the end_date of an existing coupon in the database.
	 * 
	 * @param coupon
	 *            A coupon type object
	 * @throws CouponSystemException
	 *             if it fails to update the coupon in the database
	 * 
	 */

	public void updateCoupon(Coupon coupon) throws CouponSystemException {
		couponDao.updateCoupon(coupon);

	}

	/**
	 * reads a specific coupon from the database given its ID
	 * 
	 * @param id
	 *            a coupon's ID
	 * @return A coupon type object
	 * @throws CouponSystemException
	 *             if it fails to read the coupon from the database
	 */

	public Coupon readCoupon(long id) throws CouponSystemException {
		return couponDao.readCoupon(id);
	}

	/**
	 * reads all of the coupons of a specific company from the database
	 * 
	 * @return A Collection<Coupon> with all of the company's coupons
	 * @throws CouponSystemException
	 *             if it fails to read the company's coupons from the database
	 */
	public Collection<Coupon> getAllCoupon() throws CouponSystemException {
		Company company = companyDao.getCompany(this.CompanyId);
		return companyDao.getCompanyCoupons(company);
	}

	/**
	 * reads all of the specific type coupons of a specific company from the
	 * database
	 * 
	 * @param c
	 *            CouponType type object
	 * @return Collection<Coupon> with all of the specific typed company's
	 *         coupons
	 * @throws CouponSystemException
	 *             if it fails to read the coupons from the database
	 */
	public Collection<Coupon> getCouponsByType(CouponType c) throws CouponSystemException {
		Collection<Coupon> compCouponsByType = new HashSet<>();
		Company company = companyDao.getCompany(this.CompanyId);
		compCouponsByType = companyDao.getCompanyCouponsByType(company, c);
		return compCouponsByType;
	}

	/**
	 * reads all of the coupons which their price is lower than a given price,
	 * of a specific company from the database
	 * 
	 * @param price
	 *            coupon price
	 * @return Collection<Coupon> with all of the coupons up to the given price
	 *         belong to the specific company given
	 * @throws CouponSystemException
	 *             if it fails to read the company's coupons
	 */
	public Collection<Coupon> getCouponsByPrice(double price) throws CouponSystemException {
		Company company = companyDao.getCompany(this.CompanyId);
		Collection<Coupon> compCouponByPrice = new HashSet<>();
		compCouponByPrice = companyDao.getCompanyCouponsByPrice(company, price);

		return compCouponByPrice;

	}

	/**
	 * reads from the database all of the coupons of a specific company which
	 * their end_date is before a given date.
	 * 
	 * @param date
	 *            Date type object
	 * @return Collection<Coupon> with all of the company's coupons which their
	 *         end_date is before the given date
	 * @throws CouponSystemException
	 *             if it fail to read the company's coupons from the database
	 */
	public Collection<Coupon> getCouponsByDate(Date date) throws CouponSystemException {
		Company company = companyDao.getCompany(this.CompanyId);
		Set<Coupon> compCouponByDate = new HashSet<>();
		Collection<Coupon> companyCoupons = companyDao.getCompanyCoupons(company);
		for (Coupon coupon : companyCoupons) {
			if (coupon.getEndDate().before(date) == true) {
				compCouponByDate.add(coupon);
			}
		}
		return compCouponByDate;
	}

	/**
	 * receives a company account details and try to match it with the database
	 * 
	 * @param userName
	 *            A company name
	 * @param password
	 *            A company password
	 * @param clientType
	 *            A clientType type object
	 * @return CompanyFacade instance
	 * @throws LoginException
	 *             if the user name and password aren't match
	 * @throws CouponSystemException
	 *             if it fails to search for the company name and password in
	 *             the database
	 */
	@Override
	public CouponClientFacade login(String userName, String password, ClientType clientType)
			throws SQLException, LoginException, CouponSystemException, LoginException {
		if (companyDao.login(userName, password) == true) {
			this.CompanyId = companyDao.getIdForName(userName);

			return this;
		}

		return null;

	}

}
