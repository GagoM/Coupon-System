package core.facades;

import java.sql.SQLException;

import core.Exceptions.CouponSystemException;
import core.Exceptions.LoginException;
import core.couponSystemSingleton.ClientType;

public interface CouponClientFacade {
	CouponClientFacade login(String userName, String password, ClientType clientType)
			throws SQLException, CouponSystemException, LoginException;
}
