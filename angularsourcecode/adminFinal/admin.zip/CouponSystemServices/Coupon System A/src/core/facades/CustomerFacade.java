package core.facades;

import java.sql.SQLException;
import java.util.Collection;
import java.util.HashSet;

import core.Exceptions.CouponSystemException;
import core.Exceptions.InvalidCouponException;
import core.Exceptions.LoginException;
import core.couponSystemSingleton.ClientType;
import core.daoClasses.CouponDBDAO;
import core.daoClasses.CustomerDBDAO;
import core.javaBeans.Coupon;
import core.javaBeans.CouponType;
import core.javaBeans.Customer;

public class CustomerFacade implements CouponClientFacade {

	private CustomerDBDAO customerDao = new CustomerDBDAO();
	private CouponDBDAO couponDao = new CouponDBDAO();

	private long customerId;

	public CustomerFacade() {
	}

	/**
	 * adds a new coupon to a specific customer in the customer_coupon join
	 * table, and updates the coupon's amount accordingly
	 * 
	 * @param coupon
	 *            A coupon type object
	 * @throws InvalidCouponException
	 *             if the coupon amount is zero or if the coupon's end date has
	 *             been expired
	 * @throws CouponSystemException
	 *             if it fails to add the coupon to the table
	 */

	public void purchaseCoupon(Coupon coupon) throws CouponSystemException {
		coupon.setId(couponDao.getIdForName(coupon.getTitle()));
		coupon = couponDao.readCoupon(coupon.getId());
		Customer customer = customerDao.getCustomer(this.customerId);
		customerDao.addCouponToCustomer(customer, coupon);
	}

	/**
	 * reads all of the coupons purchased by a specific customer from the
	 * database
	 * 
	 * @return Collection<Coupon> with all of the coupons from the
	 *         customer_coupon table
	 * @throws CouponSystemException
	 *             if it fails to read the customer's coupons
	 */
	public Collection<Coupon> getAllPurchasedCoupons() throws CouponSystemException {
		Customer customer = customerDao.getCustomer(this.customerId);

		return customerDao.getCustomerCoupons(customer);
	}

	/**
	 * reads from the database all of the coupons purchased by a specific
	 * customer which their type match a given coupon type
	 * 
	 * @param type
	 *            CouponType type object
	 * @return Collection<Coupon> with all of the customer's coupons that match
	 *         the given coupon type
	 * @throws CouponSystemException
	 *             if it fails to read all of the customer's coupons from the
	 *             database
	 */
	public Collection<Coupon> getAllPurchasedCouponsByType(CouponType type) throws CouponSystemException {
		Collection<Coupon> custCouponsByType = new HashSet<>();
		Customer customer = customerDao.getCustomer(this.customerId);
		custCouponsByType = customerDao.getCustomerCouponsByType(customer, type);
		return custCouponsByType;
	}

	/**
	 * reads from the database all of the coupons purchased by a specific
	 * customer which their price is lower than a given price.
	 * 
	 * @param price
	 *            coupon price
	 * @return Collection<Coupon> with all of the customer's coupons which their
	 *         price is up to the given price.
	 * @throws CouponSystemException
	 *             is it fails to read the customer's coupons from the database
	 */
	public Collection<Coupon> getAllPurchasedCouponsByPrice(double price) throws CouponSystemException {
		Customer customer = customerDao.getCustomer(this.customerId);
		return customerDao.getCustomerCouponsByPrice(customer, price);
	}

	/**
	 * receives a customer details and try to match it with the database
	 * 
	 * @param userName
	 *            A customer name @param password A customer password @param
	 *            clientType A ClientType type object @return CustomerFacade
	 *            instance
	 * @throws LoginException
	 *             if the user name and password aren't match
	 * @throws CouponSystemException
	 *             if it fails searching for the name and password in the
	 *             database
	 * @throws SQLException
	 */
	@Override
	public CouponClientFacade login(String userName, String password, ClientType clientType)
			throws CouponSystemException, SQLException {
		if (customerDao.login(userName, password) == true) {
			this.customerId = customerDao.getIdForName(userName);
			return this;

		}
		return null;

	}

}
