package core.javaBeans;

public enum CouponType {
	RESTAURANTS, ELECTRICITY, FOOD, HEALTH, SPORTS, CAMPING, TRAVELING
}
