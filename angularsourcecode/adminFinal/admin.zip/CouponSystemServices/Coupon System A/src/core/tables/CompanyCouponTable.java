package core.tables;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CompanyCouponTable {
	public static void main(String[] args) {
		String url = "jdbc:mysql://localhost:3306/CSDB";
		String driverName = "com.mysql.jdbc.Driver";
		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		String sql = "CREATE TABLE Company_Coupon (COMP_ID BIGINT , COUPON_ID INTEGER,PRIMARY KEY(COMP_ID, COUPON_ID))";
		try (Connection con = DriverManager.getConnection(url, "root", "1234");
				Statement stmt = con.createStatement();) {
			System.out.println("connected to database: " + url);

			System.out.println(sql);
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}
	}
}
