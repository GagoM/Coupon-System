package core.tables;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class CouponTable {
	public static void main(String[] args) {
		String url = "jdbc:mysql://localhost:3306/CSDB";
		try (Connection con = DriverManager.getConnection(url, "root", "1234")) {
			System.out.println("connected to database: " + url);
			Statement stmt = con.createStatement();
			String sql = "CREATE TABLE Coupon(ID BIGINT NOT NULL PRIMARY KEY AUTO_INCREMENT, TITLE varchar(30),START_DATE DATE, END_DATE DATE, AMOUNT INTEGER, TYPE VARCHAR(30), MESSAGE VARCHAR(30), PRICE FLOAT, IMAGE VARCHAR(30))";

			System.out.println(sql);
			stmt.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
