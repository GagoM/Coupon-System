package core.tables;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class CustomerCouponTable {
	public static void main(String[] args) {
		String url = "jdbc:mysql://localhost:3306/CSDB";
		try (Connection con = DriverManager.getConnection(url, "root", "1234")) {
			System.out.println("connected to database: " + url);
			Statement stmt = con.createStatement();
			String sql = "CREATE TABLE Customer_Coupon(CUST_ID BIGINT, COUPON_ID INTEGER, PRIMARY KEY(CUST_ID, COUPON_ID))";

			System.out.println(sql);
			stmt.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
