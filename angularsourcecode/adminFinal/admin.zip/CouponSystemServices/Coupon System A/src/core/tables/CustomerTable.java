package core.tables;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class CustomerTable {
	public static void main(String[] args) {
		String url = "jdbc:mysql://localhost:3306/CSDB";
		try (Connection con = DriverManager.getConnection(url, "root", "1234")) {
			System.out.println("connected to database: " + url);
			Statement stmt = con.createStatement();
			String sql = "CREATE TABLE Customer(ID BIGINT NOT NULL PRIMARY KEY AUTO_INCREMENT, CUST_NAME varchar(30),PASSWORD varchar(30))";

			System.out.println(sql);
			stmt.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
