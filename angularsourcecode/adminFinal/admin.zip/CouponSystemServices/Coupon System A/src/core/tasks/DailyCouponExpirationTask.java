package core.tasks;

import java.util.Calendar;
import java.util.Collection;
import java.util.Date;

import core.Exceptions.CouponSystemException;
import core.daoClasses.CompanyDBDAO;
import core.daoClasses.CouponDBDAO;
import core.daoClasses.CustomerDBDAO;
import core.javaBeans.Coupon;

public class DailyCouponExpirationTask implements Runnable {

	CouponDBDAO couponDBDao = new CouponDBDAO();
	CustomerDBDAO customerDBDao = new CustomerDBDAO();
	CompanyDBDAO companyDBDao = new CompanyDBDAO();
	private boolean quit = false;
	Date date = Calendar.getInstance().getTime();

	public DailyCouponExpirationTask() {
	}

	/**
	 * this thread runs a daily task once in a 24 hours that checks all of the
	 * coupons in the database, deletes the ones which their end_date has been
	 * expired
	 * 
	 */
	@Override
	public void run() {
		while (quit == false) {
			try {
				System.out.println("daily task woke up");
				Collection<Coupon> result = couponDBDao.getAllCoupon();
				for (Coupon coupon : result) {
					if (coupon.getEndDate().before(date)) {	
						couponDBDao.removeCoupon(coupon);
						companyDBDao.removeCouponFromCompany(coupon);
						customerDBDao.removeCouponFromCustomer(coupon);
					}
				}
				long timeToSleep = (long) restOfDay();
				float inHours = (restOfDay() / 3600000);
				System.out.println("daily task is going to sleep for " + inHours + " hours...");
				Thread.sleep(timeToSleep);
			} catch (InterruptedException | CouponSystemException e) {
				System.out.println("Daily task is shutting down..");
			}
		}

	}

	/**
	 * calculates the remaining time until midnight, and sending the daily task
	 * to sleep for that remaining time.
	 * 
	 * @param time
	 *            the Current time in day
	 * @return A long type object represents the amount of milliseconds remains
	 *         until midnight
	 */
	public float restOfDay() {

		Calendar cal = Calendar.getInstance();
		Date currentTime = cal.getTime();

		cal.set(Calendar.HOUR_OF_DAY, 23);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 59);
		Date endOfDay = cal.getTime();
		float timeToSleep = (endOfDay.getTime() - currentTime.getTime());
		return timeToSleep;
	}

	/**
	 * stops the daily task, and closes all of the connections
	 */
	public void stopTask() {
		this.quit = true;

	}

}
