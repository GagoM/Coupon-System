package core.test;

import java.sql.SQLException;

import core.Exceptions.CouponSystemException;
import core.couponSystemSingleton.ClientType;
import core.couponSystemSingleton.CouponSystem;
import core.facades.AdminFacade;
import core.javaBeans.Company;
import core.javaBeans.Customer;

public class AdminTest {
	public static void main(String[] args) {

		Company company = new Company();
		company.setCompName("ELECTRIC HEAD LTD1");
		company.setPassword("123456");
		company.setEmail("Ehead@gmail.com");

		Customer customer = new Customer();
		customer.setCustName("gilad1");
		customer.setPassword("123123");

		try {

			AdminFacade admin = (AdminFacade) CouponSystem.getInstance().login("admin", "1234", ClientType.Admin);
			// admin.createCompany(company);
			// admin.createCustomer(customer);

			System.out.println(admin.readAllCompanies());

			System.out.println(admin.readAllCustomer());

			System.out.println(admin.readCompany(company.getId()));

			System.out.println(admin.readCustomer(customer.getId()));

			company.setEmail("new_Email@gmail.com");
			company.setPassword("654321");
			admin.updateCompany(company);

			customer.setPassword("321321");
			admin.updateCustomer(customer);

			admin.removeCompany(company);

			admin.removeCustomer(customer);

			CouponSystem.getInstance().shutdown();

		} catch (SQLException | CouponSystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
