package core.test;

import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;

import core.Exceptions.CouponSystemException;
import core.couponSystemSingleton.ClientType;
import core.couponSystemSingleton.CouponSystem;
import core.facades.CompanyFacade;
import core.javaBeans.Coupon;
import core.javaBeans.CouponType;

public class CompanyTest {
	public static void main(String[] args) {

		Coupon coupon = new Coupon();
		coupon.setTitle("DELL laptop1");
		coupon.setAmount(50);
		coupon.setPrice(1000);
		coupon.setType(CouponType.ELECTRICITY);
		coupon.setMessage("20% off");
		Calendar cal = Calendar.getInstance();
		cal.set(2017, 0, 1);
		Date startDate = cal.getTime();
		coupon.setStartDate(new java.sql.Date(startDate.getTime()));
		cal.set(2017, 11, 31);
		Date endDate = cal.getTime();
		coupon.setEndDate(new java.sql.Date(endDate.getTime()));
		coupon.setImage("imaginary dell laptop");

		try {

			CompanyFacade c = (CompanyFacade) CouponSystem.getInstance().login("ELECTRIC HEAD LTD1", "654321",
					ClientType.Company);

			c.createCoupon(coupon);

			cal.set(2018, 3, 31);
			endDate = cal.getTime();
			coupon.setEndDate(new java.sql.Date(endDate.getTime()));
			coupon.setPrice(950);
			c.updateCoupon(coupon);

			System.out.println(c.getAllCoupon());

			System.out.println(c.getCouponsByDate(endDate));

			System.out.println(c.getCouponsByPrice(950));

			System.out.println(c.getCouponsByType(CouponType.ELECTRICITY));

			System.out.println(c.readCoupon(coupon.getId()));

			// c.removeCoupon(coupon);

			CouponSystem.getInstance().shutdown();
		} catch (SQLException | CouponSystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
