package core.test;

import java.sql.SQLException;

import core.Exceptions.CouponSystemException;
import core.couponSystemSingleton.ClientType;
import core.couponSystemSingleton.CouponSystem;
import core.facades.CustomerFacade;
import core.javaBeans.Coupon;
import core.javaBeans.CouponType;

public class CustomerTest {
	public static void main(String[] args) {

		Coupon coupon = new Coupon();
		coupon.setTitle("DELL laptop1");

		try {

			CustomerFacade customer = (CustomerFacade) CouponSystem.getInstance().login("gilad1", "321321",
					ClientType.Customer);

			customer.purchaseCoupon(coupon);

			System.out.println(customer.getAllPurchasedCoupons());

			System.out.println(customer.getAllPurchasedCouponsByPrice(950));

			System.out.println(customer.getAllPurchasedCouponsByType(CouponType.ELECTRICITY));

			CouponSystem.getInstance().shutdown();
		} catch (SQLException | CouponSystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
