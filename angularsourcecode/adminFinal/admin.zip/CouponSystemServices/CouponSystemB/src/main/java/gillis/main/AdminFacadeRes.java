package gillis.main;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import core.Exceptions.CouponSystemException;
import core.Exceptions.UniqueNameException;
import core.WebBeans.CompanyService;
import core.WebBeans.CustomerService;
import core.couponSystemSingleton.CouponSystem;
import core.facades.AdminFacade;
import core.javaBeans.Company;
import core.javaBeans.Customer;

@Path("/adminfacaderes")
public class AdminFacadeRes {

	public AdminFacade getAdminFacade() {

		AdminFacade adminFacade = (AdminFacade) CouponSystem.getInstance().login("admin", "1234", "admin");
		return adminFacade;

	}

	@Path("createcompany")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)

	public void createCompany(CompanyService c) throws CouponSystemException, UniqueNameException {
		AdminFacade adminFacade = getAdminFacade();
		if (adminFacade != null) {
			Company company = c.convertToCompany();
			adminFacade.createCompany(company);
		}

	}

	@Path("removecompany")
	@DELETE
	@Consumes(MediaType.APPLICATION_JSON)

	public void removeCompany(CompanyService c) throws CouponSystemException {
		AdminFacade adminFacade = getAdminFacade();
		if (adminFacade != null) {
			Company company = c.convertToCompany();
			adminFacade.removeCompany(company);
		}
	}

	@Path("updatecompany")
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)

	public void updateCompany(CompanyService c) throws CouponSystemException {
		AdminFacade adminFacade = getAdminFacade();
		if (adminFacade != null) {
			Company company = c.convertToCompany();
			adminFacade.updateCompany(company);
		}
	}

	// check this one
	@Path("readcompany/{id}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)

	public CompanyService readCompany(@PathParam("id") long id) throws CouponSystemException {

		AdminFacade adminFacade = getAdminFacade();
		if (adminFacade != null) {
			Company company = adminFacade.readCompany(id);
			CompanyService companyService = new CompanyService(company);
			return companyService;
		}
		return null;
	}

	@Path("readallcompanies")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Collection<CompanyService> readAllCompanies() throws CouponSystemException {
		AdminFacade adminFacade = getAdminFacade();
		if (adminFacade != null) {
			CompanyService companyService = new CompanyService();
			Collection<Company> list = new ArrayList<>();
			list = adminFacade.readAllCompanies();
			ArrayList<CompanyService> list2 = (ArrayList<CompanyService>) companyService
					.convertToCompaniesService(list);
			return list2;
		}
		return null;
	}

	@Path("createcustomer")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)

	public void createCustomer(CustomerService c) throws CouponSystemException, UniqueNameException {
		AdminFacade adminFacade = getAdminFacade();
		if (adminFacade != null) {
			Customer customer = c.convertToCustomer();
			adminFacade.createCustomer(customer);

		}

	}

	@Path("removecustomer")
	@DELETE
	@Consumes(MediaType.APPLICATION_JSON)

	public void removeCustomer(CustomerService c) throws CouponSystemException {
		AdminFacade adminFacade = getAdminFacade();
		if (adminFacade != null) {
			Customer customer = c.convertToCustomer();
			adminFacade.removeCustomer(customer);
		}
	}

	@Path("updatecustomer")
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)

	public void updateCustomer(CustomerService c) throws CouponSystemException {
		AdminFacade adminFacade = getAdminFacade();
		if (adminFacade != null) {
			Customer customer = c.convertToCustomer();
			adminFacade.updateCustomer(customer);
		}

	}

	@Path("readcustomer/{id}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public CustomerService readCustomer(@PathParam("id") long id) throws CouponSystemException {
		AdminFacade adminFacade = getAdminFacade();
		if (adminFacade != null) {
			Customer customer = adminFacade.readCustomer(id);
			CustomerService customerService = new CustomerService(customer);
			return customerService;
		}
		return null;

	}

	@Path("readallcustomer")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Collection<CustomerService> readAllCustomer() throws CouponSystemException {
		AdminFacade adminFacade = getAdminFacade();
		if (adminFacade != null) {
			CustomerService customerService = new CustomerService();
			Collection<Customer> list = new ArrayList<>();
			list = adminFacade.readAllCustomer();
			List<CustomerService> list2 = (List<CustomerService>) customerService.convertToCustomersService(list);
			return list2;
		}
		return null;
	}

}
