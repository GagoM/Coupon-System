package gillis.main;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import core.Exceptions.CouponSystemException;
import core.Exceptions.UniqueNameException;
import core.WebBeans.CouponService;
import core.couponSystemSingleton.CouponSystem;
import core.facades.CompanyFacade;
import core.javaBeans.Company;
import core.javaBeans.Coupon;
import core.javaBeans.CouponType;

@Path("/companyfacaderes")
public class CompanyFacadeRes {

	public CompanyFacade getCompanyFacade(){
		CompanyFacade companyFacade = (CompanyFacade) CouponSystem.getInstance().login("company", "company", "company");
return companyFacade;
	}
	@Path("createcoupon")
	@POST
	//cant send the date via postman
	public void createCoupon(CouponService c) throws CouponSystemException, UniqueNameException {
		CompanyFacade companyFacade = getCompanyFacade();
		if(companyFacade!=null){
			Coupon coupon = c.convertToCoupon();
			companyFacade.createCoupon(coupon);
		}
		

	}
	
@Path("removecoupon")
@DELETE
	public void removeCoupon(CouponService c) throws CouponSystemException {
	CompanyFacade companyFacade = getCompanyFacade();
	if(companyFacade!=null){
		Coupon coupon = c.convertToCoupon();
		companyFacade.removeCoupon(coupon);
	}
	}
@Path("updatecoupon")
@PUT
public void updateCoupon(CouponService c) throws CouponSystemException {
	CompanyFacade companyFacade = getCompanyFacade();
	if(companyFacade!=null){
		Coupon coupon = c.convertToCoupon();
		companyFacade.updateCoupon(coupon);
	}

}
@Path("readcoupon/{id}")
@GET
//@Consumes (MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public CouponService readCoupon(@PathParam("id")long id) throws CouponSystemException {
	CompanyFacade companyFacade = getCompanyFacade();
	if(companyFacade!=null){
		Coupon coupon = companyFacade.readCoupon(id);
		CouponService couponService = new CouponService(coupon);
		return couponService;
	}
	return null;
}
@Path("getallcoupon")
@GET
@Produces (MediaType.APPLICATION_JSON)
public Collection<CouponService> getAllCoupon() throws CouponSystemException {
	CompanyFacade companyFacade = getCompanyFacade();
	if(companyFacade!=null){
		CouponService couponService = new CouponService();
		Collection<Coupon>list = new ArrayList<>();
		list = companyFacade.getAllCoupon();
		Collection<CouponService>list2 = new ArrayList<>();
		list2 = couponService.convertToCouponsService(list);
		return list2;
	}
	return null;
}
@Path("getcouponsbytype/{type}")
@GET
@Produces (MediaType.APPLICATION_JSON)
public Collection<CouponService> getCouponsByType(@PathParam("type")CouponType c) throws CouponSystemException {
	CompanyFacade companyFacade = getCompanyFacade();
	if(companyFacade!=null){
		
		CouponService couponService = new CouponService();
		Collection<Coupon>list = new ArrayList<>();
		list = companyFacade.getCouponsByType(c);
		Collection<CouponService>list2 = new ArrayList<>();
		list2 = couponService.convertToCouponsService(list);
		return list2;
	}
	return null;
}
@Path("getcouponsbyprice/{price}")
@GET
@Produces(MediaType.APPLICATION_JSON)
public Collection<CouponService> getCouponsByPrice(@PathParam("price")double price) throws CouponSystemException {
	CompanyFacade companyFacade = getCompanyFacade();
	if(companyFacade!=null){
		CouponService couponService = new CouponService();
		Collection<Coupon>list = new ArrayList<>();
		list = companyFacade.getCouponsByPrice(price);
		Collection<CouponService>list2 = new ArrayList<>();
		list2 = couponService.convertToCouponsService(list);
		return list2;
	}
	return null;

}
//Doesn't work well
@Path("getcouponsbydate/{date}")
public Collection<CouponService> getCouponsByDate(@PathParam("date") Date date) throws CouponSystemException {
	CompanyFacade companyFacade = getCompanyFacade();
	if(companyFacade!=null){
		CouponService couponService = new CouponService();
		Collection<Coupon>list = new ArrayList<>();
		list = companyFacade.getCouponsByDate(date);
		Collection<CouponService>list2 = new ArrayList<>();
		list2 = couponService.convertToCouponsService(list);
		return list2;
	}
	return null;
}


}
