package gillis.main;


import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import core.Exceptions.CouponSystemException;
import core.WebBeans.CouponService;
import core.couponSystemSingleton.CouponSystem;
import core.facades.CustomerFacade;
import core.javaBeans.Coupon;
import core.javaBeans.CouponType;
import core.javaBeans.Customer;

@Path("/customerfacaderes")
public class CustomerFacadeRes {

	public CustomerFacade getCustomerFacade(){
		CustomerFacade customerFacade = (CustomerFacade) CouponSystem.getInstance().login("customer", "customer", "customer");
	return customerFacade;
	}
	
	@Path("purchasecoupon")
	@POST
	public void purchaseCoupon(CouponService c) throws CouponSystemException {
		CustomerFacade customerFacade = getCustomerFacade();
		if(customerFacade!=null){
			Coupon coupon = c.convertToCoupon();
			customerFacade.purchaseCoupon(coupon);
		}
		
	}
	@Path("getallpurchasedcoupons")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Collection<CouponService> getAllPurchasedCoupons() throws CouponSystemException {
		CustomerFacade customerFacade = getCustomerFacade();
		if(customerFacade!=null){
			Collection<Coupon>coupons = customerFacade.getAllPurchasedCoupons();
			CouponService couponService = new CouponService();
			Collection<CouponService>coupons1 = new ArrayList<>();
			coupons1 = couponService.convertToCouponsService(coupons);
			return coupons1;
			
		}
	return null;
	}
	
	
	@Path("getallpurchasedcouponsbytype/{type}")
	@GET
	@Produces (MediaType.APPLICATION_JSON)
	public Collection<CouponService> getAllPurchasedCouponsByType(@PathParam("type")CouponType type) throws CouponSystemException {
	
		CustomerFacade customerFacade = getCustomerFacade();
		if(customerFacade!=null){
			Collection<Coupon>coupons = customerFacade.getAllPurchasedCouponsByType(type);
			CouponService couponService = new CouponService();
			Collection<CouponService>coupons1 = new ArrayList<>();
			coupons1 = couponService.convertToCouponsService(coupons);
			return coupons1;
			
	
	}
	return null;
	}
	
	@Path("getallpurchasedcouponsbyprice/{price}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Collection<CouponService> getAllPurchasedCouponsByPrice(@PathParam("price")double price) throws CouponSystemException {
		CustomerFacade customerFacade = getCustomerFacade();
		if(customerFacade!=null){
			Collection<Coupon>coupons = customerFacade.getAllPurchasedCouponsByPrice(price);
			CouponService couponService = new CouponService();
			Collection<CouponService>coupons1 = new ArrayList<>();
			coupons1 = couponService.convertToCouponsService(coupons);
			return coupons1;
	
	}
		return null;
	}
}
