package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.research.ws.wadl.Response;

import core.Exceptions.CouponSystemException;
import core.couponSystemSingleton.ClientType;
import core.couponSystemSingleton.CouponSystem;
import core.facades.CouponClientFacade;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// connect to coupon project step A
//		<p>USER-NAME : <input type="text" name="username"></p>
//		<p>PASSWORD : <input type="password" name="password"></p>
//		<input type="radio" name="userType" value="customer" checked> Customer<br>
//		  <input type="radio" name="userType" value="company"> Company <br>
//		  <input type="radio" name="userType" value="admininstrator"> Administrator<br>
//		  <br><br>
		
		String username = request.getParameter("username");
		String pwd = request.getParameter("password");
		String clientType= request.getParameter("userType");
		
	CouponClientFacade facade = CouponSystem.getInstance().login(username, pwd, clientType);
		PrintWriter out = response.getWriter();
		out.append( "Succeed? " + (facade != null) );
		System.out.println( "Succeed? " + (facade != null));
		
		if (facade == null)
		{
			RequestDispatcher disp = request.getRequestDispatcher("/ErrorServlet");
			disp.include(request, response);
			
		}else{
			HashMap<String, String>urls = new HashMap<>();
			urls.put("admin", "http://localhost:8080/CouponSystemB/admin.html");
			urls.put("company", "http://localhost:8080/CouponSystemB/company.html");
			urls.put("customer", "http://localhost:8080/CouponSystemB/customer.html");
			response.sendRedirect(urls.get(clientType));
		
		}
	}

}
