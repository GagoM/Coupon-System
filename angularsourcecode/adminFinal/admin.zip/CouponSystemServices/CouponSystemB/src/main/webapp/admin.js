

var customerContainer = document.getElementById("customers");
var counter = 0;
var btn = document.getElementById("btn");
 function getAllCustomer(){
	 
$.ajax({ type: 'GET',
	url:"http://localhost:8080/CouponSystemB/webapi/adminfacaderes/readallcustomer",
	   dataType: 'html',
       contentType: 'application/json; charset=utf-8'}).then
(
	function(data) 
	{
		var myArray = JSON.parse(data);
		var numOfCustomers = (myArray.length);
		var name = myArray[counter].custName;
	var id = myArray[counter].id;
	var password = myArray[counter].password;
		stringHtml = "id: "+id+" name: "+name+" password: "+password+"<br>";
	customers.insertAdjacentHTML("beforebegin",stringHtml);
		counter++;
		console.log(counter);
		
		if(counter>=myArray.length){
			document.getElementById("btn").disabled = true;
			
		}
		
	
		
	}
	,function(err) 
	{ console.log(err);}		
);
}
            