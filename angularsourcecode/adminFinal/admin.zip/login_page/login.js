$(function () {
    
    $('#homeCarousel').carousel('pause');   
});