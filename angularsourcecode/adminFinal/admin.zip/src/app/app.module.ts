import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpModule }    from '@angular/http';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { CreateNewCompanyComponent } from './create-new-company/create-new-company.component';
import { EditCompaniesComponent } from './edit-companies/edit-companies.component';
import { AddNewCustomerComponent } from './add-new-customer/add-new-customer.component';
import { EditCustomersComponent } from './edit-customers/edit-customers.component';
import { GetCompanyComponent } from './get-company/get-company.component';
import { GetCustomerComponent } from './get-customer/get-customer.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    CreateNewCompanyComponent,
    EditCompaniesComponent,
    AddNewCustomerComponent,
    EditCustomersComponent,
    GetCompanyComponent,
    GetCustomerComponent
  ],
  imports: [
    FormsModule,
    HttpModule,
    BrowserModule,
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
