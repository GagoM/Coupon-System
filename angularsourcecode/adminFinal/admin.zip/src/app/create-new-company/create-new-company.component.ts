import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-new-company',
  templateUrl: './create-new-company.component.html',
  styleUrls: ['./create-new-company.component.css']
})
export class CreateNewCompanyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
