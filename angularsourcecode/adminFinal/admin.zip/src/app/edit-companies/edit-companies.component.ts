import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-companies',
  templateUrl: './edit-companies.component.html',
  styleUrls: ['./edit-companies.component.css']
})
export class EditCompaniesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
