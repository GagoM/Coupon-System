import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Http, Response, Headers } from '@angular/http';
import 'rxjs/add/operator/map'
import { Company } from '../models/company.model';

@Component({
  selector: 'app-get-company',
  templateUrl: './get-company.component.html',
  styleUrls: ['./get-company.component.css']
})
export class GetCompanyComponent implements OnInit {
  data: any = [];
  compId:number = 0;
  company:Company = new Company();
    constructor(private _http: Http) {
      // this.getAllCompanies();
    }
    getCompany(){
      return this._http.get('http://localhost:8080/CouponSystemB/webapi/adminfacaderes/readcompany/'+this.compId)
      .map((res: Response) => res.json())
       .subscribe(data => {
             this.data = JSON.stringify(data);
            this.company = new Company(data.id,data.compName,data.email,data.password);

      });
}

    
  ngOnInit(){

  }
  // public getAllCompanies() {
  //   return this._http.get('http://localhost:8080/CouponSystemB/webapi/adminfacaderes/readallcompanies')
  //               .map((res: Response) => res.json())
  //                .subscribe(data => {
  //                       this.data = data;
  //                       console.log(this.data);
  //               });
  // }
}
