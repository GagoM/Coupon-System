export class Company{
    public companyId:number;
    public companyName:string;
    public companyEmail:string;
    public companyPassword:string;
    
    constructor(id?:number, name?:string, email?:string, password?:string){
        this.companyId = id;
    this.companyName = name;
    this.companyEmail = email;
    this.companyPassword = password;
    }
    public getId():number{
        return this.companyId;
    }
    public setId(id:number){
        this.companyId=id;
    }
    public getName():string{
        return this.companyName;
    }
    public setName(name:string){
        this.companyName=name;
    }
    public getEmail():string{
        return this.companyEmail;
    }
    public setEmail(email:string){
        this.companyEmail=email;
    }
    public getPassword():string{
        return this.companyPassword;
    }
    public setPassword(password:string){
        this.companyPassword = password;
    }
    
    }